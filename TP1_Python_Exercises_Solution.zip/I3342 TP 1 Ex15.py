# Count the number of occurrences of item 50 from a tuple

tuple1 = (50, 10, 60, 70, 50)
print(f"tuple1 = {tuple1}")

print(f"Number of occurrences of item 50: {tuple1.count(50)}")
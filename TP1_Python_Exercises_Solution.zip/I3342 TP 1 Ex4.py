# Reverse a given integer number

num = 123456789

print(f"{num} in reverse is {str(num)[::-1]}")
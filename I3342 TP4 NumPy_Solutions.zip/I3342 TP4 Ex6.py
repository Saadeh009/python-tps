# Write a NumPy program to generate six random integers between 10 and 30.

import numpy as np

random_integers = np.random.randint(10, 31, 6)
print(random_integers)
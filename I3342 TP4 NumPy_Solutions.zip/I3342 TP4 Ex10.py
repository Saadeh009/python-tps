# Create a 3×3 numpy array of all True

import numpy as np

arr = np.full((3, 3), True)
print(arr)